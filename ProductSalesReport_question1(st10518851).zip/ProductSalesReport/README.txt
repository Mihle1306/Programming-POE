PRODUCT SALES REPORT - NETBEANS MAVEN PROJECT

PACKAGE
productsales

FILES
- IProducts.java: interface with the three required methods.
- Product.java: calculates total sales, average sales and most popular product.
- PrintProduct.java: prints the report.
- Main.java: accepts sales input and runs the application.
- ProductTest.java: contains the two required JUnit tests.

ARRAYS
- String[] productNames is a one-dimensional array.
- int[][] monthlySales is a two-dimensional array.
  Each row represents a product; the three columns represent months 1, 2 and 3.

SAMPLE INPUT
Cozy Nights Monarch: 25, 18, 20
Restonic Barbados: 15, 10, 12
Sealy Phuket: 18, 15, 20

EXPECTED SUMMARY
TOTAL PRODUCT SALES: 153
AVERAGE PRODUCT SALES: 17.00
MOST POPULAR PRODUCT: Cozy Nights Monarch (63)

NETBEANS
1. Extract the ZIP file.
2. Open NetBeans.
3. Select File > Open Project and choose the extracted ProductSalesReport folder.
4. Wait for Maven to load the JUnit dependency.
5. Run the project using Run Project (F6).
6. Run the tests by right-clicking the project and choosing Test.

The average is calculated across all nine product-month sales entries:
153 / 9 = 17.

The most popular product is selected by adding its sales across all three months.
