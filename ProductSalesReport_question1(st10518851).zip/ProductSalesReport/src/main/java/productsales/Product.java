package productsales;

/**
 * Stores product names and their sales for three months.
 * The productNames array is one-dimensional and monthlySales is two-dimensional.
 */
public class Product implements IProducts {

    private final String[] productNames;
    private final int[][] monthlySales;

    public Product(String[] productNames, int[][] monthlySales) {
        if (productNames == null || monthlySales == null) {
            throw new IllegalArgumentException("Product names and sales cannot be null.");
        }
        if (productNames.length == 0 || productNames.length != monthlySales.length) {
            throw new IllegalArgumentException("Each product must have a matching sales row.");
        }

        this.productNames = productNames.clone();
        this.monthlySales = new int[monthlySales.length][];

        for (int i = 0; i < monthlySales.length; i++) {
            if (monthlySales[i] == null || monthlySales[i].length == 0) {
                throw new IllegalArgumentException("Each product must have monthly sales data.");
            }
            this.monthlySales[i] = monthlySales[i].clone();

            for (int sale : this.monthlySales[i]) {
                if (sale < 0) {
                    throw new IllegalArgumentException("Sales cannot be negative.");
                }
            }
        }
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;

        for (int[] productSales : monthlySales) {
            for (int sale : productSales) {
                total += sale;
            }
        }

        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int totalEntries = 0;

        for (int[] productSales : monthlySales) {
            totalEntries += productSales.length;
        }

        if (totalEntries == 0) {
            return 0.0;
        }

        return (double) GetTotalProductsSold() / totalEntries;
    }

    @Override
    public String GetMostPopularProduct() {
        int highestTotal = -1;
        String mostPopular = productNames[0];

        for (int i = 0; i < monthlySales.length; i++) {
            int productTotal = 0;

            for (int sale : monthlySales[i]) {
                productTotal += sale;
            }

            if (productTotal > highestTotal) {
                highestTotal = productTotal;
                mostPopular = productNames[i];
            }
        }

        return mostPopular;
    }

    /**
     * Returns the total sales for one product, identified by its array position.
     */
    public int getProductTotal(int productIndex) {
        if (productIndex < 0 || productIndex >= monthlySales.length) {
            throw new IndexOutOfBoundsException("Invalid product index.");
        }

        int total = 0;
        for (int sale : monthlySales[productIndex]) {
            total += sale;
        }
        return total;
    }

    public String[] getProductNames() {
        return productNames.clone();
    }
}
