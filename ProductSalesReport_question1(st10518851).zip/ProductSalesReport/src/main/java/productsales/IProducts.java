package productsales;

/**
 * Describes the calculations required for the product sales report.
 */
public interface IProducts {
    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}
