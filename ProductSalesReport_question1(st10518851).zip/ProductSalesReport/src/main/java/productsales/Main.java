package productsales;

import java.util.Scanner;

/**
 * Main class: collects three months of sales and displays the report.
 */
public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // One-dimensional array containing the product names.
        String[] productNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        // Two-dimensional array: each row is a product and each column is a month.
        int[][] monthlySales = new int[productNames.length][3];

        for (int product = 0; product < productNames.length; product++) {
            for (int month = 0; month < 3; month++) {
                monthlySales[product][month] = readSales(
                        input, month + 1, productNames[product]);
            }
            System.out.println();
        }

        Product product = new Product(productNames, monthlySales);
        PrintProduct printer = new PrintProduct(product);
        printer.printReport();

        input.close();
    }

    private static int readSales(Scanner input, int month, String productName) {
        while (true) {
            System.out.print("Enter number of sales for month " + month
                    + " for " + productName + " mattress: ");

            if (input.hasNextInt()) {
                int sales = input.nextInt();

                if (sales >= 0) {
                    return sales;
                }

                System.out.println("Please enter zero or a positive number.");
            } else {
                System.out.println("Invalid input. Please enter a whole number.");
                input.next();
            }
        }
    }
}
