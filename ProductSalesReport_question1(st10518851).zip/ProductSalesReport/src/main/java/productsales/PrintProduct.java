package productsales;

/**
 * Prints the calculated information for the product sales report.
 */
public class PrintProduct {

    private final Product product;

    public PrintProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null.");
        }
        this.product = product;
    }

    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void printAverageProductSales() {
        System.out.printf("AVERAGE PRODUCT SALES: %.2f%n",
                product.GetAverageProductSold());
    }

    public void printMostPopularProduct() {
        String name = product.GetMostPopularProduct();

        for (int i = 0; i < product.getProductNames().length; i++) {
            if (product.getProductNames()[i].equals(name)) {
                System.out.println("MOST POPULAR PRODUCT: " + name
                        + " (" + product.getProductTotal(i) + ")");
                return;
            }
        }

        System.out.println("MOST POPULAR PRODUCT: " + name);
    }

    public void printReport() {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("****************************************");
        printTotalProductSales();
        printAverageProductSales();
        printMostPopularProduct();
        System.out.println("****************************************");
    }
}
