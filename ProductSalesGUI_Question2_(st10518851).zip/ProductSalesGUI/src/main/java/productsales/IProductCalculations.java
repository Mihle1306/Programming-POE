package productsales;

public interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}
