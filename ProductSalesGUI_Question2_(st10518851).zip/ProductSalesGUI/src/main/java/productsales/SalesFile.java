package productsales;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Appends each processed sale to data.txt in the application's working directory.
 */
public class SalesFile {
    private final Path filePath;

    public SalesFile() {
        this(Path.of("data.txt"));
    }

    public SalesFile(Path filePath) {
        this.filePath = filePath;
    }

    public void save(SalesRecord record) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(
                filePath,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND)) {

            writer.write("DATA LOG");
            writer.newLine();
            writer.write("****************************************");
            writer.newLine();
            writer.write("Customer Name: " + record.getCustomerName());
            writer.newLine();
            writer.write("Product: " + record.getProductName());
            writer.newLine();
            writer.write(String.format("VAT: R %.2f", record.getVat()));
            writer.newLine();
            writer.write(String.format("COMMISSION: R %.2f", record.getCommission()));
            writer.newLine();
            writer.write(String.format("TOTAL: R %.2f", record.getTotal()));
            writer.newLine();
            writer.write("****************************************");
            writer.newLine();
            writer.newLine();
        }
    }
}
