package productsales;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Swing GUI for processing mattress sales.
 */
public class ProductApp extends JFrame {

    private final JTextField customerNameField = new JTextField(22);
    private final JComboBox<String> productCombo = new JComboBox<>(new String[] {
        "Cozy Nights Monarch",
        "Restonic Barbados",
        "Sealy Phuket"
    });
    private final JTextField priceField = new JTextField(22);
    private final JButton processButton = new JButton("PROCESS");
    private final SalesFile salesFile = new SalesFile();
    private final NumberFormat currency = NumberFormat.getNumberInstance(Locale.US);

    public ProductApp() {
        super("Product App");
        currency.setMinimumFractionDigits(2);
        currency.setMaximumFractionDigits(2);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 330);
        setLocationRelativeTo(null);
        setJMenuBar(createMenuBar());
        add(createForm(), BorderLayout.CENTER);

        processButton.addActionListener(event -> processSale());
    }

    private JPanel createForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addRow(panel, gbc, 0, "Customer Name:", customerNameField);
        addRow(panel, gbc, 1, "Select Product:", productCombo);
        addRow(panel, gbc, 2, "Enter Price:", priceField);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weightx = 1;
        panel.add(processButton, gbc);

        return panel;
    }

    private void addRow(JPanel panel, GridBagConstraints gbc, int row,
                        String label, java.awt.Component field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        panel.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        panel.add(field, gbc);
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(event -> dispose());
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(event -> processSale());

        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(event -> clearForm());

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    private void processSale() {
        String customerName = customerNameField.getText().trim();
        String productName = (String) productCombo.getSelectedItem();
        String priceText = priceField.getText().trim();

        if (customerName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer's name.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            customerNameField.requestFocus();
            return;
        }

        if (priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the product price.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            priceField.requestFocus();
            return;
        }

        final double price;
        try {
            price = Double.parseDouble(priceText);
            if (!Double.isFinite(price) || price < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this,
                    "Enter a valid price using numbers only (zero or more).",
                    "Invalid Price", JOptionPane.ERROR_MESSAGE);
            priceField.requestFocus();
            return;
        }

        ProductCalculations calculations = new ProductCalculations(price);
        SalesRecord record = new SalesRecord(
                customerName,
                productName,
                price,
                calculations.GetVat(),
                calculations.GetCommission(),
                calculations.GetTotal()
        );

        try {
            salesFile.save(record);
        } catch (IOException exception) {
            JOptionPane.showMessageDialog(this,
                    "The sale could not be saved to data.txt: " + exception.getMessage(),
                    "File Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String message = "Customer Name: " + record.getCustomerName()
                + "\nProduct " + record.getProductName()
                + "\nVAT: R " + currency.format(record.getVat())
                + "\nCOMMISSION: R " + currency.format(record.getCommission())
                + "\nTOTAL: R " + currency.format(record.getTotal());

        JOptionPane.showMessageDialog(this, message, "Message",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearForm() {
        customerNameField.setText("");
        priceField.setText("");
        productCombo.setSelectedIndex(0);
        customerNameField.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
