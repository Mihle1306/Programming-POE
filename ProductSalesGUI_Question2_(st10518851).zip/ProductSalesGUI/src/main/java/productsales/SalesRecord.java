package productsales;

/**
 * Holds the details for one processed customer sale.
 */
public class SalesRecord {
    private final String customerName;
    private final String productName;
    private final double productPrice;
    private final double vat;
    private final double commission;
    private final double total;

    public SalesRecord(String customerName, String productName, double productPrice,
                       double vat, double commission, double total) {
        this.customerName = customerName;
        this.productName = productName;
        this.productPrice = productPrice;
        this.vat = vat;
        this.commission = commission;
        this.total = total;
    }

    public String getCustomerName() { return customerName; }
    public String getProductName() { return productName; }
    public double getProductPrice() { return productPrice; }
    public double getVat() { return vat; }
    public double getCommission() { return commission; }
    public double getTotal() { return total; }
}
