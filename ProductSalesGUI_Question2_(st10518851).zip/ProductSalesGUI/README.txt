PRODUCT APP - QUESTION 2
Java Swing / NetBeans Maven project

FEATURES IMPLEMENTED
Q2.1 - GUI application for mattress sales.
Q2.2 - Customer name text field, product combo box and price text field.
       Products: Cozy Nights Monarch, Restonic Barbados, Sealy Phuket.
Q2.3 - Process button calculates VAT, commission and total and appends
       the details to data.txt.
Q2.4 - File > Exit; Tools > Process; Tools > Clear.
       Clear empties both text fields and resets the combo box to index 0.
Q2.5 - IProductCalculations interface and ProductCalculations class.
Q2.6 - JUnit tests for GetVat and GetTotal.

CALCULATIONS
VAT = product price * 15%
Commission = product price * 5%
Total = product price + VAT + commission

SAMPLE
Price: R 3500
VAT: R 525
Commission: R 175
Total: R 4200

PROJECT STRUCTURE
src/main/java/productsales/
  IProductCalculations.java
  ProductCalculations.java
  SalesRecord.java
  SalesFile.java
  ProductApp.java

src/test/java/productsales/
  ProductCalculationsTest.java

RUN IN NETBEANS
1. Extract ProductSalesGUI_NetBeans_Maven.zip.
2. Open NetBeans.
3. Select File > Open Project.
4. Select the extracted ProductSalesGUI folder.
5. Wait for Maven dependencies to load.
6. Run the project (F6). The Product App window should open.
7. Enter a customer name, choose a mattress, enter a price and click PROCESS.
8. The result appears in a message dialog. data.txt is created/appended
   in the project's working directory.
9. Right-click the project and choose Test to run both JUnit tests.

The application uses Java Swing and JUnit 5. It does not require a database.
